const services = [
  { name: "Bridals & Makeup",           slug: "bridal-makeup",     path: "/bridal-makeup" },
  { name: "Hair Services",              slug: "hair-services",     path: "/hair-services" },
  { name: "Face Treatments",            slug: "face-treatments",   path: "/face-treatments" },
  { name: "Body Treatments",            slug: "body-treatments",   path: "/body-treatments" },
  { name: "Manicure & Pedicure",        slug: "manicure",          path: "/manicure" },
  { name: "Waxing, Threading & Polish", slug: "waxing",            path: "/waxing" },
];

export default services;